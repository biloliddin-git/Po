using System.Collections;
using UnityEngine;

public class PowerUpSpawner : MonoBehaviour
{
    public GameObject speedPowerUpPrefab; // Assign Speed PowerUp prefab
    public GameObject sizePowerUpPrefab; // Assign Size PowerUp prefab
    public float spawnInterval = 5f; // Time between potential spawns
    public Vector2 spawnAreaMin; // Define spawn area bounds
    public Vector2 spawnAreaMax;

    private int currentPowerUps = 0; // Track the number of power-ups on the field
    private const int maxPowerUps = 2; // Max number of power-ups on the field

    void Start()
    {
        StartCoroutine(SpawnPowerUps());
    }

    private IEnumerator SpawnPowerUps()
    {
        // Wait for a few seconds before starting to spawn
        yield return new WaitForSeconds(3f); // Wait for 3 seconds before spawning

        while (true)
        {
            if (currentPowerUps < maxPowerUps)
            {
                yield return new WaitForSeconds(spawnInterval);
                SpawnPowerUp();
            }
            else
            {
                yield return null; // Wait until there's space for a new power-up
            }
        }
    }

    private void SpawnPowerUp()
    {
        Vector2 spawnPosition = new Vector2(
            Random.Range(spawnAreaMin.x, spawnAreaMax.x),
            Random.Range(spawnAreaMin.y, spawnAreaMax.y)
        );

        GameObject powerUpToSpawn = Random.value > 0.5f ? speedPowerUpPrefab : sizePowerUpPrefab;
        GameObject powerUp = Instantiate(powerUpToSpawn, spawnPosition, Quaternion.identity);
        
        // Increment the count of active power-ups
        currentPowerUps++;
        StartCoroutine(CheckPowerUpCount(powerUp));
    }

    private IEnumerator CheckPowerUpCount(GameObject powerUp)
    {
        // Wait until the power-up is collected or destroyed
        yield return new WaitUntil(() => powerUp == null);
        currentPowerUps--; // Decrement the count when the power-up is gone
    }
}
