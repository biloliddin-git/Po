using System.Collections;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerUpType { IncreaseSpeed, IncreaseSize }
    public PowerUpType powerUpType;
    public float duration = 5f; // Duration of the effect

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Ball")) // Ensure your ball has this tag
        {
            ActivatePowerUp(other.gameObject);
            StartCoroutine(DisappearingEffect());
        }
    }

    private void ActivatePowerUp(GameObject ball)
    {
        BallController ballController = ball.GetComponent<BallController>();
        if (ballController != null && ballController.player != null)
        {
            PlayerController player = ballController.player;
            switch (powerUpType)
            {
                case PowerUpType.IncreaseSpeed:
                    player.StartCoroutine(player.IncreaseSpeed(duration));
                    break;
                case PowerUpType.IncreaseSize:
                    player.StartCoroutine(player.IncreaseSize(duration));
                    break;
            }
        }
    }

    private IEnumerator DisappearingEffect()
    {
        GetComponent<Collider2D>().enabled = false; // Disable the collider
        GetComponent<SpriteRenderer>().enabled = false; // Hide the sprite

        yield return new WaitForSeconds(5f); // Wait for 5 seconds

        Destroy(gameObject); // Destroy the power-up
    }
}
