using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 10f;
    private float originalSpeed;
    private Vector3 originalScale;
    public bool isPlayerA = false;
    public GameObject circle;

    private Rigidbody2D rb;
    private Vector2 playerMovement;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        originalSpeed = speed; // Store the original speed
        originalScale = transform.localScale; // Store the original scale
    }

    void Update()
    {
        if (isPlayerA)
        {
            PaddleAController();
        }
        else
        {
            PaddleBController();
        }
    }

    private void PaddleBController()
    {
        if (circle.transform.position.y > transform.position.y + 0.5f)
        {
            playerMovement = new Vector2(0, 1);
        }
        else if (circle.transform.position.y < transform.position.y - 0.5f)
        {
            playerMovement = new Vector2(0, -1);
        }
        else
        {
            playerMovement = Vector2.zero;
        }
    }

    private void PaddleAController()
    {
        playerMovement = new Vector2(0, Input.GetAxis("Vertical"));
    }

    private void FixedUpdate()
    {
        rb.velocity = playerMovement * speed;
    }

    public IEnumerator IncreaseSpeed(float duration)
    {
        speed *= 1.5f; // Increase speed by 50%
        yield return new WaitForSeconds(duration);
        speed = originalSpeed; // Reset to original speed
    }

    public IEnumerator IncreaseSize(float duration)
    {
        transform.localScale *= 1.5f; // Increase size by 50%
        yield return new WaitForSeconds(duration);
        transform.localScale = originalScale; // Reset to original size
    }
}
